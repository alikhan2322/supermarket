package services.impl;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import services.*;
	
public class ServiceManager {
	
	private static Map<String, List> AllServiceInstance = new HashMap<String, List>();
	
	private static List<SuperMarketSystem> SuperMarketSystemInstances = new LinkedList<SuperMarketSystem>();
	private static List<ThirdPartyServices> ThirdPartyServicesInstances = new LinkedList<ThirdPartyServices>();
	private static List<StartNewSaleService> StartNewSaleServiceInstances = new LinkedList<StartNewSaleService>();
	private static List<ScanItemService> ScanItemServiceInstances = new LinkedList<ScanItemService>();
	
	static {
		AllServiceInstance.put("SuperMarketSystem", SuperMarketSystemInstances);
		AllServiceInstance.put("ThirdPartyServices", ThirdPartyServicesInstances);
		AllServiceInstance.put("StartNewSaleService", StartNewSaleServiceInstances);
		AllServiceInstance.put("ScanItemService", ScanItemServiceInstances);
	} 
	
	public static List getAllInstancesOf(String ClassName) {
			 return AllServiceInstance.get(ClassName);
	}	
	
	public static SuperMarketSystem createSuperMarketSystem() {
		SuperMarketSystem s = new SuperMarketSystemImpl();
		SuperMarketSystemInstances.add(s);
		return s;
	}
	public static ThirdPartyServices createThirdPartyServices() {
		ThirdPartyServices s = new ThirdPartyServicesImpl();
		ThirdPartyServicesInstances.add(s);
		return s;
	}
	public static StartNewSaleService createStartNewSaleService() {
		StartNewSaleService s = new StartNewSaleServiceImpl();
		StartNewSaleServiceInstances.add(s);
		return s;
	}
	public static ScanItemService createScanItemService() {
		ScanItemService s = new ScanItemServiceImpl();
		ScanItemServiceInstances.add(s);
		return s;
	}
}	
