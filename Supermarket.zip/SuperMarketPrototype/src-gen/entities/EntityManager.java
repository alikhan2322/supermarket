package entities;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.lang.reflect.Method;
import java.util.Map;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.Serializable;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.File;

public class EntityManager {

	private static Map<String, List> AllInstance = new HashMap<String, List>();
	
	private static List<Customer> CustomerInstances = new LinkedList<Customer>();
	private static List<Sale> SaleInstances = new LinkedList<Sale>();
	private static List<Saleslineitem> SaleslineitemInstances = new LinkedList<Saleslineitem>();
	private static List<ProductCataloge> ProductCatalogeInstances = new LinkedList<ProductCataloge>();
	private static List<Store> StoreInstances = new LinkedList<Store>();
	private static List<Payment> PaymentInstances = new LinkedList<Payment>();

	
	/* Put instances list into Map */
	static {
		AllInstance.put("Customer", CustomerInstances);
		AllInstance.put("Sale", SaleInstances);
		AllInstance.put("Saleslineitem", SaleslineitemInstances);
		AllInstance.put("ProductCataloge", ProductCatalogeInstances);
		AllInstance.put("Store", StoreInstances);
		AllInstance.put("Payment", PaymentInstances);
	} 
		
	/* Save State */
	public static void save(File file) {
		
		try {
			
			ObjectOutputStream stateSave = new ObjectOutputStream(new FileOutputStream(file));
			
			stateSave.writeObject(CustomerInstances);
			stateSave.writeObject(SaleInstances);
			stateSave.writeObject(SaleslineitemInstances);
			stateSave.writeObject(ProductCatalogeInstances);
			stateSave.writeObject(StoreInstances);
			stateSave.writeObject(PaymentInstances);
			
			stateSave.close();
					
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/* Load State */
	public static void load(File file) {
		
		try {
			
			ObjectInputStream stateLoad = new ObjectInputStream(new FileInputStream(file));
			
			try {
				
				CustomerInstances =  (List<Customer>) stateLoad.readObject();
				AllInstance.put("Customer", CustomerInstances);
				SaleInstances =  (List<Sale>) stateLoad.readObject();
				AllInstance.put("Sale", SaleInstances);
				SaleslineitemInstances =  (List<Saleslineitem>) stateLoad.readObject();
				AllInstance.put("Saleslineitem", SaleslineitemInstances);
				ProductCatalogeInstances =  (List<ProductCataloge>) stateLoad.readObject();
				AllInstance.put("ProductCataloge", ProductCatalogeInstances);
				StoreInstances =  (List<Store>) stateLoad.readObject();
				AllInstance.put("Store", StoreInstances);
				PaymentInstances =  (List<Payment>) stateLoad.readObject();
				AllInstance.put("Payment", PaymentInstances);
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		
	/* create object */  
	public static Object createObject(String Classifer) {
		try
		{
			Class c = Class.forName("entities.EntityManager");
			Method createObjectMethod = c.getDeclaredMethod("create" + Classifer + "Object");
			return createObjectMethod.invoke(c);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	/* add object */  
	public static Object addObject(String Classifer, Object ob) {
		try
		{
			Class c = Class.forName("entities.EntityManager");
			Method addObjectMethod = c.getDeclaredMethod("add" + Classifer + "Object", Class.forName("entities." + Classifer));
			return  (boolean) addObjectMethod.invoke(c, ob);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}	
	
	/* add objects */  
	public static Object addObjects(String Classifer, List obs) {
		try
		{
			Class c = Class.forName("entities.EntityManager");
			Method addObjectsMethod = c.getDeclaredMethod("add" + Classifer + "Objects", Class.forName("java.util.List"));
			return  (boolean) addObjectsMethod.invoke(c, obs);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	/* Release object */
	public static boolean deleteObject(String Classifer, Object ob) {
		try
		{
			Class c = Class.forName("entities.EntityManager");
			Method deleteObjectMethod = c.getDeclaredMethod("delete" + Classifer + "Object", Class.forName("entities." + Classifer));
			return  (boolean) deleteObjectMethod.invoke(c, ob);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}
	
	/* Release objects */
	public static boolean deleteObjects(String Classifer, List obs) {
		try
		{
			Class c = Class.forName("entities.EntityManager");
			Method deleteObjectMethod = c.getDeclaredMethod("delete" + Classifer + "Objects", Class.forName("java.util.List"));
			return  (boolean) deleteObjectMethod.invoke(c, obs);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}		 	
	
	 /* Get all objects belongs to same class */
	public static List getAllInstancesOf(String ClassName) {
			 return AllInstance.get(ClassName);
	}	

   /* Sub-create object */
	public static Customer createCustomerObject() {
		Customer o = new Customer();
		return o;
	}
	
	public static boolean addCustomerObject(Customer o) {
		return CustomerInstances.add(o);
	}
	
	public static boolean addCustomerObjects(List<Customer> os) {
		return CustomerInstances.addAll(os);
	}
	
	public static boolean deleteCustomerObject(Customer o) {
		return CustomerInstances.remove(o);
	}
	
	public static boolean deleteCustomerObjects(List<Customer> os) {
		return CustomerInstances.removeAll(os);
	}
	public static Sale createSaleObject() {
		Sale o = new Sale();
		return o;
	}
	
	public static boolean addSaleObject(Sale o) {
		return SaleInstances.add(o);
	}
	
	public static boolean addSaleObjects(List<Sale> os) {
		return SaleInstances.addAll(os);
	}
	
	public static boolean deleteSaleObject(Sale o) {
		return SaleInstances.remove(o);
	}
	
	public static boolean deleteSaleObjects(List<Sale> os) {
		return SaleInstances.removeAll(os);
	}
	public static Saleslineitem createSaleslineitemObject() {
		Saleslineitem o = new Saleslineitem();
		return o;
	}
	
	public static boolean addSaleslineitemObject(Saleslineitem o) {
		return SaleslineitemInstances.add(o);
	}
	
	public static boolean addSaleslineitemObjects(List<Saleslineitem> os) {
		return SaleslineitemInstances.addAll(os);
	}
	
	public static boolean deleteSaleslineitemObject(Saleslineitem o) {
		return SaleslineitemInstances.remove(o);
	}
	
	public static boolean deleteSaleslineitemObjects(List<Saleslineitem> os) {
		return SaleslineitemInstances.removeAll(os);
	}
	public static ProductCataloge createProductCatalogeObject() {
		ProductCataloge o = new ProductCataloge();
		return o;
	}
	
	public static boolean addProductCatalogeObject(ProductCataloge o) {
		return ProductCatalogeInstances.add(o);
	}
	
	public static boolean addProductCatalogeObjects(List<ProductCataloge> os) {
		return ProductCatalogeInstances.addAll(os);
	}
	
	public static boolean deleteProductCatalogeObject(ProductCataloge o) {
		return ProductCatalogeInstances.remove(o);
	}
	
	public static boolean deleteProductCatalogeObjects(List<ProductCataloge> os) {
		return ProductCatalogeInstances.removeAll(os);
	}
	public static Store createStoreObject() {
		Store o = new Store();
		return o;
	}
	
	public static boolean addStoreObject(Store o) {
		return StoreInstances.add(o);
	}
	
	public static boolean addStoreObjects(List<Store> os) {
		return StoreInstances.addAll(os);
	}
	
	public static boolean deleteStoreObject(Store o) {
		return StoreInstances.remove(o);
	}
	
	public static boolean deleteStoreObjects(List<Store> os) {
		return StoreInstances.removeAll(os);
	}
	public static Payment createPaymentObject() {
		Payment o = new Payment();
		return o;
	}
	
	public static boolean addPaymentObject(Payment o) {
		return PaymentInstances.add(o);
	}
	
	public static boolean addPaymentObjects(List<Payment> os) {
		return PaymentInstances.addAll(os);
	}
	
	public static boolean deletePaymentObject(Payment o) {
		return PaymentInstances.remove(o);
	}
	
	public static boolean deletePaymentObjects(List<Payment> os) {
		return PaymentInstances.removeAll(os);
	}
  
}

