package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Payment implements Serializable {
	
	/* all primary attributes */
	private int TotalAmount;
	private String PaymentMode;
	private int PaymentID;
	
	/* all references */
	private Sale PaymenttoSale; 
	
	/* all get and set functions */
	public int getTotalAmount() {
		return TotalAmount;
	}	
	
	public void setTotalAmount(int totalamount) {
		this.TotalAmount = totalamount;
	}
	public String getPaymentMode() {
		return PaymentMode;
	}	
	
	public void setPaymentMode(String paymentmode) {
		this.PaymentMode = paymentmode;
	}
	public int getPaymentID() {
		return PaymentID;
	}	
	
	public void setPaymentID(int paymentid) {
		this.PaymentID = paymentid;
	}
	
	/* all functions for reference*/
	public Sale getPaymenttoSale() {
		return PaymenttoSale;
	}	
	
	public void setPaymenttoSale(Sale sale) {
		this.PaymenttoSale = sale;
	}			
	


}
