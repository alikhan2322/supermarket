package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Saleslineitem extends Sale  implements Serializable {
	
	/* all primary attributes */
	private int Itemquantity;
	
	/* all references */
	private ProductCataloge SaleslineitemtoProductCataloge; 
	
	/* all get and set functions */
	public int getItemquantity() {
		return Itemquantity;
	}	
	
	public void setItemquantity(int itemquantity) {
		this.Itemquantity = itemquantity;
	}
	
	/* all functions for reference*/
	public ProductCataloge getSaleslineitemtoProductCataloge() {
		return SaleslineitemtoProductCataloge;
	}	
	
	public void setSaleslineitemtoProductCataloge(ProductCataloge productcataloge) {
		this.SaleslineitemtoProductCataloge = productcataloge;
	}			
	


}
