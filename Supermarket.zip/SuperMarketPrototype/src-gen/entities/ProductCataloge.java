package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class ProductCataloge implements Serializable {
	
	/* all primary attributes */
	private int ID;
	private String Name;
	private String Br;
	
	/* all references */
	private Store ProductCatalogetoStore; 
	
	/* all get and set functions */
	public int getID() {
		return ID;
	}	
	
	public void setID(int id) {
		this.ID = id;
	}
	public String getName() {
		return Name;
	}	
	
	public void setName(String name) {
		this.Name = name;
	}
	public String getBr() {
		return Br;
	}	
	
	public void setBr(String br) {
		this.Br = br;
	}
	
	/* all functions for reference*/
	public Store getProductCatalogetoStore() {
		return ProductCatalogetoStore;
	}	
	
	public void setProductCatalogetoStore(Store store) {
		this.ProductCatalogetoStore = store;
	}			
	


}
