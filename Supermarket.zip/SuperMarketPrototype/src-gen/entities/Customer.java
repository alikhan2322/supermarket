package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Customer implements Serializable {
	
	/* all primary attributes */
	private String Name;
	private String Adress;
	private String Gender;
	private int Age;
	private int Phone;
	
	/* all references */
	private Sale CustomertoSale; 
	
	/* all get and set functions */
	public String getName() {
		return Name;
	}	
	
	public void setName(String name) {
		this.Name = name;
	}
	public String getAdress() {
		return Adress;
	}	
	
	public void setAdress(String adress) {
		this.Adress = adress;
	}
	public String getGender() {
		return Gender;
	}	
	
	public void setGender(String gender) {
		this.Gender = gender;
	}
	public int getAge() {
		return Age;
	}	
	
	public void setAge(int age) {
		this.Age = age;
	}
	public int getPhone() {
		return Phone;
	}	
	
	public void setPhone(int phone) {
		this.Phone = phone;
	}
	
	/* all functions for reference*/
	public Sale getCustomertoSale() {
		return CustomertoSale;
	}	
	
	public void setCustomertoSale(Sale sale) {
		this.CustomertoSale = sale;
	}			
	


}
