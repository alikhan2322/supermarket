package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Sale implements Serializable {
	
	/* all primary attributes */
	private int Time;
	private String Type;
	
	/* all references */
	private Payment SaletoPayment; 
	private Store SaletoStore; 
	private Customer SaletoCustomer; 
	
	/* all get and set functions */
	public int getTime() {
		return Time;
	}	
	
	public void setTime(int time) {
		this.Time = time;
	}
	public String getType() {
		return Type;
	}	
	
	public void setType(String type) {
		this.Type = type;
	}
	
	/* all functions for reference*/
	public Payment getSaletoPayment() {
		return SaletoPayment;
	}	
	
	public void setSaletoPayment(Payment payment) {
		this.SaletoPayment = payment;
	}			
	public Store getSaletoStore() {
		return SaletoStore;
	}	
	
	public void setSaletoStore(Store store) {
		this.SaletoStore = store;
	}			
	public Customer getSaletoCustomer() {
		return SaletoCustomer;
	}	
	
	public void setSaletoCustomer(Customer customer) {
		this.SaletoCustomer = customer;
	}			
	


}
