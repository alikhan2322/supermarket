package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Store implements Serializable {
	
	/* all primary attributes */
	private int StoreID;
	private String StoreLocation;
	private int StorePhone;
	
	/* all references */
	private Sale StoretoSale; 
	
	/* all get and set functions */
	public int getStoreID() {
		return StoreID;
	}	
	
	public void setStoreID(int storeid) {
		this.StoreID = storeid;
	}
	public String getStoreLocation() {
		return StoreLocation;
	}	
	
	public void setStoreLocation(String storelocation) {
		this.StoreLocation = storelocation;
	}
	public int getStorePhone() {
		return StorePhone;
	}	
	
	public void setStorePhone(int storephone) {
		this.StorePhone = storephone;
	}
	
	/* all functions for reference*/
	public Sale getStoretoSale() {
		return StoretoSale;
	}	
	
	public void setStoretoSale(Sale sale) {
		this.StoretoSale = sale;
	}			
	


}
