package gui;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableView;
import javafx.scene.control.TabPane;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Modality;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.Tooltip;

import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import java.io.File;
import javafx.scene.control.cell.PropertyValueFactory;
import java.util.List;
import java.time.LocalDate;
import java.util.LinkedList;

import java.lang.reflect.Array;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;

import gui.supportclass.*;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.value.ObservableValue;
import javafx.util.Callback;
import services.*;
import services.impl.*;
import java.time.format.DateTimeFormatter;
import java.lang.reflect.Method;

import entities.*;

public class PrototypeController implements Initializable {


	DateTimeFormatter dateformatter;
	 
	@Override
	public void initialize(URL location, ResourceBundle resources) {
	
		supermarketsystem_service = ServiceManager.createSuperMarketSystem();
		thirdpartyservices_service = ServiceManager.createThirdPartyServices();
		startnewsaleservice_service = ServiceManager.createStartNewSaleService();
		scanitemservice_service = ServiceManager.createScanItemService();
				
		this.dateformatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		
	   	 //prepare data for contract
	   	 prepareData();
	   	 
	   	 //generate invariant panel
	   	 genereateInvairantPanel();
	   	 
		 //Actor Threeview Binding
		 actorTreeViewBinding();
		 
		 //Generate
		 generatOperationPane();
		 genereateOpInvariantPanel();
		 
		 //prilimariry data
		 try {
			DataFitService.fit();
		 } catch (PreconditionException e) {
			// TODO Auto-generated catch block
		 	e.printStackTrace();
		 }
		 
		 //generate class statistic
		 classStatisicBingding();
		 
		 //generate object statistic
		 generateObjectTable();
		 
		 //genereate association statistic
		 associationStatisicBingding();

		 //set listener 
		 setListeners();
	}
	
	/**
	 * deepCopyforTreeItem (Actor Generation)
	 */
	TreeItem<String> deepCopyTree(TreeItem<String> item) {
		    TreeItem<String> copy = new TreeItem<String>(item.getValue());
		    for (TreeItem<String> child : item.getChildren()) {
		        copy.getChildren().add(deepCopyTree(child));
		    }
		    return copy;
	}
	
	/**
	 * check all invariant and update invariant panel
	 */
	public void invairantPanelUpdate() {
		
		try {
			
			for (Entry<String, Label> inv : entity_invariants_label_map.entrySet()) {
				String invname = inv.getKey();
				String[] invt = invname.split("_");
				String entityName = invt[0];
				for (Object o : EntityManager.getAllInstancesOf(entityName)) {				
					 Method m = o.getClass().getMethod(invname);
					 if ((boolean)m.invoke(o) == false) {
						 inv.getValue().setStyle("-fx-max-width: Infinity;" + 
									"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #af0c27 100%);" +
								    "-fx-padding: 6px;" +
								    "-fx-border-color: black;");
						 break;
					 }
				}				
			}
			
			for (Entry<String, Label> inv : service_invariants_label_map.entrySet()) {
				String invname = inv.getKey();
				String[] invt = invname.split("_");
				String serviceName = invt[0];
				for (Object o : ServiceManager.getAllInstancesOf(serviceName)) {				
					 Method m = o.getClass().getMethod(invname);
					 if ((boolean)m.invoke(o) == false) {
						 inv.getValue().setStyle("-fx-max-width: Infinity;" + 
									"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #af0c27 100%);" +
								    "-fx-padding: 6px;" +
								    "-fx-border-color: black;");
						 break;
					 }
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	

	/**
	 * check op invariant and update op invariant panel
	 */		
	public void opInvairantPanelUpdate() {
		
		try {
			
			for (Entry<String, Label> inv : op_entity_invariants_label_map.entrySet()) {
				String invname = inv.getKey();
				String[] invt = invname.split("_");
				String entityName = invt[0];
				for (Object o : EntityManager.getAllInstancesOf(entityName)) {
					 Method m = o.getClass().getMethod(invname);
					 if ((boolean)m.invoke(o) == false) {
						 inv.getValue().setStyle("-fx-max-width: Infinity;" + 
									"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #af0c27 100%);" +
								    "-fx-padding: 6px;" +
								    "-fx-border-color: black;");
						 break;
					 }
				}
			}
			
			for (Entry<String, Label> inv : op_service_invariants_label_map.entrySet()) {
				String invname = inv.getKey();
				String[] invt = invname.split("_");
				String serviceName = invt[0];
				for (Object o : ServiceManager.getAllInstancesOf(serviceName)) {
					 Method m = o.getClass().getMethod(invname);
					 if ((boolean)m.invoke(o) == false) {
						 inv.getValue().setStyle("-fx-max-width: Infinity;" + 
									"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #af0c27 100%);" +
								    "-fx-padding: 6px;" +
								    "-fx-border-color: black;");
						 break;
					 }
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/* 
	*	generate op invariant panel 
	*/
	public void genereateOpInvariantPanel() {
		
		opInvariantPanel = new HashMap<String, VBox>();
		op_entity_invariants_label_map = new LinkedHashMap<String, Label>();
		op_service_invariants_label_map = new LinkedHashMap<String, Label>();
		
		VBox v;
		List<String> entities;
		
	}
	
	
	/*
	*  generate invariant panel
	*/
	public void genereateInvairantPanel() {
		
		service_invariants_label_map = new LinkedHashMap<String, Label>();
		entity_invariants_label_map = new LinkedHashMap<String, Label>();
		
		//entity_invariants_map
		VBox v = new VBox();
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			Label l = new Label(inv.getKey());
			l.setStyle("-fx-max-width: Infinity;" + 
					"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
				    "-fx-padding: 6px;" +
				    "-fx-border-color: black;");
			
			Tooltip tp = new Tooltip();
			tp.setText(inv.getValue());
			l.setTooltip(tp);
			
			service_invariants_label_map.put(inv.getKey(), l);
			v.getChildren().add(l);
			
		}
		//entity invariants
		for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
			
			String INVname = inv.getKey();
			Label l = new Label(INVname);
			if (INVname.contains("AssociationInvariants")) {
				l.setStyle("-fx-max-width: Infinity;" + 
					"-fx-background-color: linear-gradient(to right, #099b17 0%, #F0FFFF 100%);" +
				    "-fx-padding: 6px;" +
				    "-fx-border-color: black;");
			} else {
				l.setStyle("-fx-max-width: Infinity;" + 
									"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
								    "-fx-padding: 6px;" +
								    "-fx-border-color: black;");
			}	
			Tooltip tp = new Tooltip();
			tp.setText(inv.getValue());
			l.setTooltip(tp);
			
			entity_invariants_label_map.put(inv.getKey(), l);
			v.getChildren().add(l);
			
		}
		ScrollPane scrollPane = new ScrollPane(v);
		scrollPane.setFitToWidth(true);
		all_invariant_pane.setMaxHeight(850);
		
		all_invariant_pane.setContent(scrollPane);
	}	
	
	
	
	/* 
	*	mainPane add listener
	*/
	public void setListeners() {
		 mainPane.getSelectionModel().selectedItemProperty().addListener((ov, oldTab, newTab) -> {
			 
			 	if (newTab.getText().equals("System State")) {
			 		System.out.println("refresh all");
			 		refreshAll();
			 	}
		    
		    });
	}
	
	
	//checking all invariants
	public void checkAllInvariants() {
		
		invairantPanelUpdate();
	
	}	
	
	//refresh all
	public void refreshAll() {
		
		invairantPanelUpdate();
		classStatisticUpdate();
		generateObjectTable();
	}
	
	
	//update association
	public void updateAssociation(String className) {
		
		for (AssociationInfo assoc : allassociationData.get(className)) {
			assoc.computeAssociationNumber();
		}
		
	}
	
	public void updateAssociation(String className, int index) {
		
		for (AssociationInfo assoc : allassociationData.get(className)) {
			assoc.computeAssociationNumber(index);
		}
		
	}	
	
	public void generateObjectTable() {
		
		allObjectTables = new LinkedHashMap<String, TableView>();
		
		TableView<Map<String, String>> tableCustomer = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableCustomer_Name = new TableColumn<Map<String, String>, String>("Name");
		tableCustomer_Name.setMinWidth("Name".length()*10);
		tableCustomer_Name.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Name"));
		    }
		});	
		tableCustomer.getColumns().add(tableCustomer_Name);
		TableColumn<Map<String, String>, String> tableCustomer_Adress = new TableColumn<Map<String, String>, String>("Adress");
		tableCustomer_Adress.setMinWidth("Adress".length()*10);
		tableCustomer_Adress.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Adress"));
		    }
		});	
		tableCustomer.getColumns().add(tableCustomer_Adress);
		TableColumn<Map<String, String>, String> tableCustomer_Gender = new TableColumn<Map<String, String>, String>("Gender");
		tableCustomer_Gender.setMinWidth("Gender".length()*10);
		tableCustomer_Gender.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Gender"));
		    }
		});	
		tableCustomer.getColumns().add(tableCustomer_Gender);
		TableColumn<Map<String, String>, String> tableCustomer_Age = new TableColumn<Map<String, String>, String>("Age");
		tableCustomer_Age.setMinWidth("Age".length()*10);
		tableCustomer_Age.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Age"));
		    }
		});	
		tableCustomer.getColumns().add(tableCustomer_Age);
		TableColumn<Map<String, String>, String> tableCustomer_Phone = new TableColumn<Map<String, String>, String>("Phone");
		tableCustomer_Phone.setMinWidth("Phone".length()*10);
		tableCustomer_Phone.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Phone"));
		    }
		});	
		tableCustomer.getColumns().add(tableCustomer_Phone);
		
		//table data
		ObservableList<Map<String, String>> dataCustomer = FXCollections.observableArrayList();
		List<Customer> rsCustomer = EntityManager.getAllInstancesOf("Customer");
		for (Customer r : rsCustomer) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getName() != null)
				unit.put("Name", String.valueOf(r.getName()));
			else
				unit.put("Name", "");
			if (r.getAdress() != null)
				unit.put("Adress", String.valueOf(r.getAdress()));
			else
				unit.put("Adress", "");
			if (r.getGender() != null)
				unit.put("Gender", String.valueOf(r.getGender()));
			else
				unit.put("Gender", "");
			unit.put("Age", String.valueOf(r.getAge()));
			unit.put("Phone", String.valueOf(r.getPhone()));

			dataCustomer.add(unit);
		}
		
		tableCustomer.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableCustomer.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Customer", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableCustomer.setItems(dataCustomer);
		allObjectTables.put("Customer", tableCustomer);
		
		TableView<Map<String, String>> tableSale = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableSale_Time = new TableColumn<Map<String, String>, String>("Time");
		tableSale_Time.setMinWidth("Time".length()*10);
		tableSale_Time.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Time"));
		    }
		});	
		tableSale.getColumns().add(tableSale_Time);
		TableColumn<Map<String, String>, String> tableSale_Type = new TableColumn<Map<String, String>, String>("Type");
		tableSale_Type.setMinWidth("Type".length()*10);
		tableSale_Type.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Type"));
		    }
		});	
		tableSale.getColumns().add(tableSale_Type);
		
		//table data
		ObservableList<Map<String, String>> dataSale = FXCollections.observableArrayList();
		List<Sale> rsSale = EntityManager.getAllInstancesOf("Sale");
		for (Sale r : rsSale) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			unit.put("Time", String.valueOf(r.getTime()));
			if (r.getType() != null)
				unit.put("Type", String.valueOf(r.getType()));
			else
				unit.put("Type", "");

			dataSale.add(unit);
		}
		
		tableSale.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableSale.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Sale", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableSale.setItems(dataSale);
		allObjectTables.put("Sale", tableSale);
		
		TableView<Map<String, String>> tableSaleslineitem = new TableView<Map<String, String>>();

		//super entity attribute column
		TableColumn<Map<String, String>, String> tableSaleslineitem_Time = new TableColumn<Map<String, String>, String>("Time");
		tableSaleslineitem_Time.setMinWidth("Time".length()*10);
		tableSaleslineitem_Time.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Time"));
		    }
		});	
		tableSaleslineitem.getColumns().add(tableSaleslineitem_Time);
		TableColumn<Map<String, String>, String> tableSaleslineitem_Type = new TableColumn<Map<String, String>, String>("Type");
		tableSaleslineitem_Type.setMinWidth("Type".length()*10);
		tableSaleslineitem_Type.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Type"));
		    }
		});	
		tableSaleslineitem.getColumns().add(tableSaleslineitem_Type);
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableSaleslineitem_Itemquantity = new TableColumn<Map<String, String>, String>("Itemquantity");
		tableSaleslineitem_Itemquantity.setMinWidth("Itemquantity".length()*10);
		tableSaleslineitem_Itemquantity.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Itemquantity"));
		    }
		});	
		tableSaleslineitem.getColumns().add(tableSaleslineitem_Itemquantity);
		
		//table data
		ObservableList<Map<String, String>> dataSaleslineitem = FXCollections.observableArrayList();
		List<Saleslineitem> rsSaleslineitem = EntityManager.getAllInstancesOf("Saleslineitem");
		for (Saleslineitem r : rsSaleslineitem) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			unit.put("Time", String.valueOf(r.getTime()));
			if (r.getType() != null)
				unit.put("Type", String.valueOf(r.getType()));
			else
				unit.put("Type", "");
			
			unit.put("Itemquantity", String.valueOf(r.getItemquantity()));

			dataSaleslineitem.add(unit);
		}
		
		tableSaleslineitem.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableSaleslineitem.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Saleslineitem", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableSaleslineitem.setItems(dataSaleslineitem);
		allObjectTables.put("Saleslineitem", tableSaleslineitem);
		
		TableView<Map<String, String>> tableProductCataloge = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableProductCataloge_ID = new TableColumn<Map<String, String>, String>("ID");
		tableProductCataloge_ID.setMinWidth("ID".length()*10);
		tableProductCataloge_ID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("ID"));
		    }
		});	
		tableProductCataloge.getColumns().add(tableProductCataloge_ID);
		TableColumn<Map<String, String>, String> tableProductCataloge_Name = new TableColumn<Map<String, String>, String>("Name");
		tableProductCataloge_Name.setMinWidth("Name".length()*10);
		tableProductCataloge_Name.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Name"));
		    }
		});	
		tableProductCataloge.getColumns().add(tableProductCataloge_Name);
		TableColumn<Map<String, String>, String> tableProductCataloge_Br = new TableColumn<Map<String, String>, String>("Br");
		tableProductCataloge_Br.setMinWidth("Br".length()*10);
		tableProductCataloge_Br.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Br"));
		    }
		});	
		tableProductCataloge.getColumns().add(tableProductCataloge_Br);
		
		//table data
		ObservableList<Map<String, String>> dataProductCataloge = FXCollections.observableArrayList();
		List<ProductCataloge> rsProductCataloge = EntityManager.getAllInstancesOf("ProductCataloge");
		for (ProductCataloge r : rsProductCataloge) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			unit.put("ID", String.valueOf(r.getID()));
			if (r.getName() != null)
				unit.put("Name", String.valueOf(r.getName()));
			else
				unit.put("Name", "");
			if (r.getBr() != null)
				unit.put("Br", String.valueOf(r.getBr()));
			else
				unit.put("Br", "");

			dataProductCataloge.add(unit);
		}
		
		tableProductCataloge.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableProductCataloge.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("ProductCataloge", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableProductCataloge.setItems(dataProductCataloge);
		allObjectTables.put("ProductCataloge", tableProductCataloge);
		
		TableView<Map<String, String>> tableStore = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableStore_StoreID = new TableColumn<Map<String, String>, String>("StoreID");
		tableStore_StoreID.setMinWidth("StoreID".length()*10);
		tableStore_StoreID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("StoreID"));
		    }
		});	
		tableStore.getColumns().add(tableStore_StoreID);
		TableColumn<Map<String, String>, String> tableStore_StoreLocation = new TableColumn<Map<String, String>, String>("StoreLocation");
		tableStore_StoreLocation.setMinWidth("StoreLocation".length()*10);
		tableStore_StoreLocation.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("StoreLocation"));
		    }
		});	
		tableStore.getColumns().add(tableStore_StoreLocation);
		TableColumn<Map<String, String>, String> tableStore_StorePhone = new TableColumn<Map<String, String>, String>("StorePhone");
		tableStore_StorePhone.setMinWidth("StorePhone".length()*10);
		tableStore_StorePhone.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("StorePhone"));
		    }
		});	
		tableStore.getColumns().add(tableStore_StorePhone);
		
		//table data
		ObservableList<Map<String, String>> dataStore = FXCollections.observableArrayList();
		List<Store> rsStore = EntityManager.getAllInstancesOf("Store");
		for (Store r : rsStore) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			unit.put("StoreID", String.valueOf(r.getStoreID()));
			if (r.getStoreLocation() != null)
				unit.put("StoreLocation", String.valueOf(r.getStoreLocation()));
			else
				unit.put("StoreLocation", "");
			unit.put("StorePhone", String.valueOf(r.getStorePhone()));

			dataStore.add(unit);
		}
		
		tableStore.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableStore.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Store", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableStore.setItems(dataStore);
		allObjectTables.put("Store", tableStore);
		
		TableView<Map<String, String>> tablePayment = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tablePayment_TotalAmount = new TableColumn<Map<String, String>, String>("TotalAmount");
		tablePayment_TotalAmount.setMinWidth("TotalAmount".length()*10);
		tablePayment_TotalAmount.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("TotalAmount"));
		    }
		});	
		tablePayment.getColumns().add(tablePayment_TotalAmount);
		TableColumn<Map<String, String>, String> tablePayment_PaymentMode = new TableColumn<Map<String, String>, String>("PaymentMode");
		tablePayment_PaymentMode.setMinWidth("PaymentMode".length()*10);
		tablePayment_PaymentMode.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("PaymentMode"));
		    }
		});	
		tablePayment.getColumns().add(tablePayment_PaymentMode);
		TableColumn<Map<String, String>, String> tablePayment_PaymentID = new TableColumn<Map<String, String>, String>("PaymentID");
		tablePayment_PaymentID.setMinWidth("PaymentID".length()*10);
		tablePayment_PaymentID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("PaymentID"));
		    }
		});	
		tablePayment.getColumns().add(tablePayment_PaymentID);
		
		//table data
		ObservableList<Map<String, String>> dataPayment = FXCollections.observableArrayList();
		List<Payment> rsPayment = EntityManager.getAllInstancesOf("Payment");
		for (Payment r : rsPayment) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			unit.put("TotalAmount", String.valueOf(r.getTotalAmount()));
			if (r.getPaymentMode() != null)
				unit.put("PaymentMode", String.valueOf(r.getPaymentMode()));
			else
				unit.put("PaymentMode", "");
			unit.put("PaymentID", String.valueOf(r.getPaymentID()));

			dataPayment.add(unit);
		}
		
		tablePayment.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tablePayment.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Payment", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tablePayment.setItems(dataPayment);
		allObjectTables.put("Payment", tablePayment);
		

		
	}
	
	/* 
	* update all object tables with sub dataset
	*/ 
	public void updateCustomerTable(List<Customer> rsCustomer) {
			ObservableList<Map<String, String>> dataCustomer = FXCollections.observableArrayList();
			for (Customer r : rsCustomer) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getName() != null)
					unit.put("Name", String.valueOf(r.getName()));
				else
					unit.put("Name", "");
				if (r.getAdress() != null)
					unit.put("Adress", String.valueOf(r.getAdress()));
				else
					unit.put("Adress", "");
				if (r.getGender() != null)
					unit.put("Gender", String.valueOf(r.getGender()));
				else
					unit.put("Gender", "");
				unit.put("Age", String.valueOf(r.getAge()));
				unit.put("Phone", String.valueOf(r.getPhone()));
				dataCustomer.add(unit);
			}
			
			allObjectTables.get("Customer").setItems(dataCustomer);
	}
	public void updateSaleTable(List<Sale> rsSale) {
			ObservableList<Map<String, String>> dataSale = FXCollections.observableArrayList();
			for (Sale r : rsSale) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				unit.put("Time", String.valueOf(r.getTime()));
				if (r.getType() != null)
					unit.put("Type", String.valueOf(r.getType()));
				else
					unit.put("Type", "");
				dataSale.add(unit);
			}
			
			allObjectTables.get("Sale").setItems(dataSale);
	}
	public void updateSaleslineitemTable(List<Saleslineitem> rsSaleslineitem) {
			ObservableList<Map<String, String>> dataSaleslineitem = FXCollections.observableArrayList();
			for (Saleslineitem r : rsSaleslineitem) {
				Map<String, String> unit = new HashMap<String, String>();
				
				unit.put("Time", String.valueOf(r.getTime()));
				if (r.getType() != null)
					unit.put("Type", String.valueOf(r.getType()));
				else
					unit.put("Type", "");
				
				unit.put("Itemquantity", String.valueOf(r.getItemquantity()));
				dataSaleslineitem.add(unit);
			}
			
			allObjectTables.get("Saleslineitem").setItems(dataSaleslineitem);
	}
	public void updateProductCatalogeTable(List<ProductCataloge> rsProductCataloge) {
			ObservableList<Map<String, String>> dataProductCataloge = FXCollections.observableArrayList();
			for (ProductCataloge r : rsProductCataloge) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				unit.put("ID", String.valueOf(r.getID()));
				if (r.getName() != null)
					unit.put("Name", String.valueOf(r.getName()));
				else
					unit.put("Name", "");
				if (r.getBr() != null)
					unit.put("Br", String.valueOf(r.getBr()));
				else
					unit.put("Br", "");
				dataProductCataloge.add(unit);
			}
			
			allObjectTables.get("ProductCataloge").setItems(dataProductCataloge);
	}
	public void updateStoreTable(List<Store> rsStore) {
			ObservableList<Map<String, String>> dataStore = FXCollections.observableArrayList();
			for (Store r : rsStore) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				unit.put("StoreID", String.valueOf(r.getStoreID()));
				if (r.getStoreLocation() != null)
					unit.put("StoreLocation", String.valueOf(r.getStoreLocation()));
				else
					unit.put("StoreLocation", "");
				unit.put("StorePhone", String.valueOf(r.getStorePhone()));
				dataStore.add(unit);
			}
			
			allObjectTables.get("Store").setItems(dataStore);
	}
	public void updatePaymentTable(List<Payment> rsPayment) {
			ObservableList<Map<String, String>> dataPayment = FXCollections.observableArrayList();
			for (Payment r : rsPayment) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				unit.put("TotalAmount", String.valueOf(r.getTotalAmount()));
				if (r.getPaymentMode() != null)
					unit.put("PaymentMode", String.valueOf(r.getPaymentMode()));
				else
					unit.put("PaymentMode", "");
				unit.put("PaymentID", String.valueOf(r.getPaymentID()));
				dataPayment.add(unit);
			}
			
			allObjectTables.get("Payment").setItems(dataPayment);
	}
	
	/* 
	* update all object tables
	*/ 
	public void updateCustomerTable() {
			ObservableList<Map<String, String>> dataCustomer = FXCollections.observableArrayList();
			List<Customer> rsCustomer = EntityManager.getAllInstancesOf("Customer");
			for (Customer r : rsCustomer) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getName() != null)
					unit.put("Name", String.valueOf(r.getName()));
				else
					unit.put("Name", "");
				if (r.getAdress() != null)
					unit.put("Adress", String.valueOf(r.getAdress()));
				else
					unit.put("Adress", "");
				if (r.getGender() != null)
					unit.put("Gender", String.valueOf(r.getGender()));
				else
					unit.put("Gender", "");
				unit.put("Age", String.valueOf(r.getAge()));
				unit.put("Phone", String.valueOf(r.getPhone()));
				dataCustomer.add(unit);
			}
			
			allObjectTables.get("Customer").setItems(dataCustomer);
	}
	public void updateSaleTable() {
			ObservableList<Map<String, String>> dataSale = FXCollections.observableArrayList();
			List<Sale> rsSale = EntityManager.getAllInstancesOf("Sale");
			for (Sale r : rsSale) {
				Map<String, String> unit = new HashMap<String, String>();


				unit.put("Time", String.valueOf(r.getTime()));
				if (r.getType() != null)
					unit.put("Type", String.valueOf(r.getType()));
				else
					unit.put("Type", "");
				dataSale.add(unit);
			}
			
			allObjectTables.get("Sale").setItems(dataSale);
	}
	public void updateSaleslineitemTable() {
			ObservableList<Map<String, String>> dataSaleslineitem = FXCollections.observableArrayList();
			List<Saleslineitem> rsSaleslineitem = EntityManager.getAllInstancesOf("Saleslineitem");
			for (Saleslineitem r : rsSaleslineitem) {
				Map<String, String> unit = new HashMap<String, String>();

				unit.put("Time", String.valueOf(r.getTime()));
				if (r.getType() != null)
					unit.put("Type", String.valueOf(r.getType()));
				else
					unit.put("Type", "");

				unit.put("Itemquantity", String.valueOf(r.getItemquantity()));
				dataSaleslineitem.add(unit);
			}
			
			allObjectTables.get("Saleslineitem").setItems(dataSaleslineitem);
	}
	public void updateProductCatalogeTable() {
			ObservableList<Map<String, String>> dataProductCataloge = FXCollections.observableArrayList();
			List<ProductCataloge> rsProductCataloge = EntityManager.getAllInstancesOf("ProductCataloge");
			for (ProductCataloge r : rsProductCataloge) {
				Map<String, String> unit = new HashMap<String, String>();


				unit.put("ID", String.valueOf(r.getID()));
				if (r.getName() != null)
					unit.put("Name", String.valueOf(r.getName()));
				else
					unit.put("Name", "");
				if (r.getBr() != null)
					unit.put("Br", String.valueOf(r.getBr()));
				else
					unit.put("Br", "");
				dataProductCataloge.add(unit);
			}
			
			allObjectTables.get("ProductCataloge").setItems(dataProductCataloge);
	}
	public void updateStoreTable() {
			ObservableList<Map<String, String>> dataStore = FXCollections.observableArrayList();
			List<Store> rsStore = EntityManager.getAllInstancesOf("Store");
			for (Store r : rsStore) {
				Map<String, String> unit = new HashMap<String, String>();


				unit.put("StoreID", String.valueOf(r.getStoreID()));
				if (r.getStoreLocation() != null)
					unit.put("StoreLocation", String.valueOf(r.getStoreLocation()));
				else
					unit.put("StoreLocation", "");
				unit.put("StorePhone", String.valueOf(r.getStorePhone()));
				dataStore.add(unit);
			}
			
			allObjectTables.get("Store").setItems(dataStore);
	}
	public void updatePaymentTable() {
			ObservableList<Map<String, String>> dataPayment = FXCollections.observableArrayList();
			List<Payment> rsPayment = EntityManager.getAllInstancesOf("Payment");
			for (Payment r : rsPayment) {
				Map<String, String> unit = new HashMap<String, String>();


				unit.put("TotalAmount", String.valueOf(r.getTotalAmount()));
				if (r.getPaymentMode() != null)
					unit.put("PaymentMode", String.valueOf(r.getPaymentMode()));
				else
					unit.put("PaymentMode", "");
				unit.put("PaymentID", String.valueOf(r.getPaymentID()));
				dataPayment.add(unit);
			}
			
			allObjectTables.get("Payment").setItems(dataPayment);
	}
	
	public void classStatisicBingding() {
	
		 classInfodata = FXCollections.observableArrayList();
	 	 customer = new ClassInfo("Customer", EntityManager.getAllInstancesOf("Customer").size());
	 	 classInfodata.add(customer);
	 	 sale = new ClassInfo("Sale", EntityManager.getAllInstancesOf("Sale").size());
	 	 classInfodata.add(sale);
	 	 saleslineitem = new ClassInfo("Saleslineitem", EntityManager.getAllInstancesOf("Saleslineitem").size());
	 	 classInfodata.add(saleslineitem);
	 	 productcataloge = new ClassInfo("ProductCataloge", EntityManager.getAllInstancesOf("ProductCataloge").size());
	 	 classInfodata.add(productcataloge);
	 	 store = new ClassInfo("Store", EntityManager.getAllInstancesOf("Store").size());
	 	 classInfodata.add(store);
	 	 payment = new ClassInfo("Payment", EntityManager.getAllInstancesOf("Payment").size());
	 	 classInfodata.add(payment);
	 	 
		 class_statisic.setItems(classInfodata);
		 
		 //Class Statisic Binding
		 class_statisic.getSelectionModel().selectedItemProperty().addListener(
				 (observable, oldValue, newValue) ->  { 
				 										 //no selected object in table
				 										 objectindex = -1;
				 										 
				 										 //get lastest data, reflect updateTableData method
				 										 try {
												 			 Method updateob = this.getClass().getMethod("update" + newValue.getName() + "Table", null);
												 			 updateob.invoke(this);			 
												 		 } catch (Exception e) {
												 		 	 e.printStackTrace();
												 		 }		 										 
				 	
				 										 //show object table
				 			 				 			 TableView obs = allObjectTables.get(newValue.getName());
				 			 				 			 if (obs != null) {
				 			 				 				object_statics.setContent(obs);
				 			 				 				object_statics.setText("All Objects " + newValue.getName() + ":");
				 			 				 			 }
				 			 				 			 
				 			 				 			 //update association information
							 			 				 updateAssociation(newValue.getName());
				 			 				 			 
				 			 				 			 //show association information
				 			 				 			 ObservableList<AssociationInfo> asso = allassociationData.get(newValue.getName());
				 			 				 			 if (asso != null) {
				 			 				 			 	association_statisic.setItems(asso);
				 			 				 			 }
				 			 				 		  });
	}
	
	public void classStatisticUpdate() {
	 	 customer.setNumber(EntityManager.getAllInstancesOf("Customer").size());
	 	 sale.setNumber(EntityManager.getAllInstancesOf("Sale").size());
	 	 saleslineitem.setNumber(EntityManager.getAllInstancesOf("Saleslineitem").size());
	 	 productcataloge.setNumber(EntityManager.getAllInstancesOf("ProductCataloge").size());
	 	 store.setNumber(EntityManager.getAllInstancesOf("Store").size());
	 	 payment.setNumber(EntityManager.getAllInstancesOf("Payment").size());
		
	}
	
	/**
	 * association binding
	 */
	public void associationStatisicBingding() {
		
		allassociationData = new HashMap<String, ObservableList<AssociationInfo>>();
		
		ObservableList<AssociationInfo> Customer_association_data = FXCollections.observableArrayList();
		AssociationInfo Customer_associatition_CustomertoSale = new AssociationInfo("Customer", "Sale", "CustomertoSale", false);
		Customer_association_data.add(Customer_associatition_CustomertoSale);
		
		allassociationData.put("Customer", Customer_association_data);
		
		ObservableList<AssociationInfo> Sale_association_data = FXCollections.observableArrayList();
		AssociationInfo Sale_associatition_SaletoPayment = new AssociationInfo("Sale", "Payment", "SaletoPayment", false);
		Sale_association_data.add(Sale_associatition_SaletoPayment);
		AssociationInfo Sale_associatition_SaletoStore = new AssociationInfo("Sale", "Store", "SaletoStore", false);
		Sale_association_data.add(Sale_associatition_SaletoStore);
		AssociationInfo Sale_associatition_SaletoCustomer = new AssociationInfo("Sale", "Customer", "SaletoCustomer", false);
		Sale_association_data.add(Sale_associatition_SaletoCustomer);
		
		allassociationData.put("Sale", Sale_association_data);
		
		ObservableList<AssociationInfo> Saleslineitem_association_data = FXCollections.observableArrayList();
		AssociationInfo Saleslineitem_associatition_SaleslineitemtoProductCataloge = new AssociationInfo("Saleslineitem", "ProductCataloge", "SaleslineitemtoProductCataloge", false);
		Saleslineitem_association_data.add(Saleslineitem_associatition_SaleslineitemtoProductCataloge);
		
		allassociationData.put("Saleslineitem", Saleslineitem_association_data);
		
		ObservableList<AssociationInfo> ProductCataloge_association_data = FXCollections.observableArrayList();
		AssociationInfo ProductCataloge_associatition_ProductCatalogetoStore = new AssociationInfo("ProductCataloge", "Store", "ProductCatalogetoStore", false);
		ProductCataloge_association_data.add(ProductCataloge_associatition_ProductCatalogetoStore);
		
		allassociationData.put("ProductCataloge", ProductCataloge_association_data);
		
		ObservableList<AssociationInfo> Store_association_data = FXCollections.observableArrayList();
		AssociationInfo Store_associatition_StoretoSale = new AssociationInfo("Store", "Sale", "StoretoSale", false);
		Store_association_data.add(Store_associatition_StoretoSale);
		
		allassociationData.put("Store", Store_association_data);
		
		ObservableList<AssociationInfo> Payment_association_data = FXCollections.observableArrayList();
		AssociationInfo Payment_associatition_PaymenttoSale = new AssociationInfo("Payment", "Sale", "PaymenttoSale", false);
		Payment_association_data.add(Payment_associatition_PaymenttoSale);
		
		allassociationData.put("Payment", Payment_association_data);
		
		
		association_statisic.getSelectionModel().selectedItemProperty().addListener(
			    (observable, oldValue, newValue) ->  { 
	
							 		if (newValue != null) {
							 			 try {
							 			 	 if (newValue.getNumber() != 0) {
								 				 //choose object or not
								 				 if (objectindex != -1) {
									 				 Class[] cArg = new Class[1];
									 				 cArg[0] = List.class;
									 				 //reflect updateTableData method
										 			 Method updateob = this.getClass().getMethod("update" + newValue.getTargetClass() + "Table", cArg);
										 			 //find choosen object
										 			 Object selectedob = EntityManager.getAllInstancesOf(newValue.getSourceClass()).get(objectindex);
										 			 //reflect find association method
										 			 Method getAssociatedObject = selectedob.getClass().getMethod("get" + newValue.getAssociationName());
										 			 List r = new LinkedList();
										 			 //one or mulity?
										 			 if (newValue.getIsMultiple() == true) {
											 			 
											 			r = (List) getAssociatedObject.invoke(selectedob);
										 			 }
										 			 else {
										 				r.add(getAssociatedObject.invoke(selectedob));
										 			 }
										 			 //invoke update method
										 			 updateob.invoke(this, r);
										 			  
										 			 
								 				 }
												 //bind updated data to GUI
					 				 			 TableView obs = allObjectTables.get(newValue.getTargetClass());
					 				 			 if (obs != null) {
					 				 				object_statics.setContent(obs);
					 				 				object_statics.setText("Targets Objects " + newValue.getTargetClass() + ":");
					 				 			 }
					 				 		 }
							 			 }
							 			 catch (Exception e) {
							 				 e.printStackTrace();
							 			 }
							 		}
					 		  });
		
	}	
	
	

    //prepare data for contract
	public void prepareData() {
		
		//definition map
		definitions_map = new HashMap<String, String>();
		
		//precondition map
		preconditions_map = new HashMap<String, String>();
		
		//postcondition map
		postconditions_map = new HashMap<String, String>();
		
		//service invariants map
		service_invariants_map = new LinkedHashMap<String, String>();
		
		//entity invariants map
		entity_invariants_map = new LinkedHashMap<String, String>();
		
	}
	
	public void generatOperationPane() {
		
		 operationPanels = new LinkedHashMap<String, GridPane>();
		
	}	

	public void actorTreeViewBinding() {
		
		 
		
		
		 
		TreeItem<String> treeRootcashier = new TreeItem<String>("Root node");
			TreeItem<String> subTreeRoot_startNewSale = new TreeItem<String>("startNewSale");
			subTreeRoot_startNewSale.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("startNewSale"),
					 	new TreeItem<String>("enterItem")
				 		));	
			TreeItem<String> subTreeRoot_scanItem = new TreeItem<String>("scanItem");
			subTreeRoot_scanItem.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("makeCashPayment"),
					 	new TreeItem<String>("makeCardPayment")
				 		));	
		
		treeRootcashier.getChildren().addAll(Arrays.asList(
			subTreeRoot_startNewSale,
			subTreeRoot_scanItem,
			new TreeItem<String>("printRecipt")
					));
		
		treeRootcashier.setExpanded(true);

		actor_treeview_cashier.setShowRoot(false);
		actor_treeview_cashier.setRoot(treeRootcashier);
		
		//TreeView click, then open the GridPane for inputing parameters
		actor_treeview_cashier.getSelectionModel().selectedItemProperty().addListener(
						 (observable, oldValue, newValue) -> { 
						 								
						 							 //clear the previous return
													 operation_return_pane.setContent(new Label());
													 
						 							 clickedOp = newValue.getValue();
						 							 GridPane op = operationPanels.get(clickedOp);
						 							 VBox vb = opInvariantPanel.get(clickedOp);
						 							 
						 							 //op pannel
						 							 if (op != null) {
						 								 operation_paras.setContent(operationPanels.get(newValue.getValue()));
						 								 
						 								 ObservableList<Node> l = operationPanels.get(newValue.getValue()).getChildren();
						 								 choosenOperation = new LinkedList<TextField>();
						 								 for (Node n : l) {
						 								 	 if (n instanceof TextField) {
						 								 	 	choosenOperation.add((TextField)n);
						 								 	  }
						 								 }
						 								 
						 								 definition.setText(definitions_map.get(newValue.getValue()));
						 								 precondition.setText(preconditions_map.get(newValue.getValue()));
						 								 postcondition.setText(postconditions_map.get(newValue.getValue()));
						 								 
						 						     }
						 							 else {
						 								 Label l = new Label(newValue.getValue() + " is no contract information in requirement model.");
						 								 l.setPadding(new Insets(8, 8, 8, 8));
						 								 operation_paras.setContent(l);
						 							 }	
						 							 
						 							 //op invariants
						 							 if (vb != null) {
						 							 	ScrollPane scrollPane = new ScrollPane(vb);
						 							 	scrollPane.setFitToWidth(true);
						 							 	invariants_panes.setMaxHeight(200); 
						 							 	//all_invariant_pane.setContent(scrollPane);	
						 							 	
						 							 	invariants_panes.setContent(scrollPane);
						 							 } else {
						 							 	 Label l = new Label(newValue.getValue() + " is no related invariants");
						 							     l.setPadding(new Insets(8, 8, 8, 8));
						 							     invariants_panes.setContent(l);
						 							 }
						 							 
						 							 //reset pre- and post-conditions area color
						 							 precondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF ");
						 							 postcondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF");
						 							 //reset condition panel title
						 							 precondition_pane.setText("Precondition");
						 							 postcondition_pane.setText("Postcondition");
						 						} 
						 				);
		TreeItem<String> treeRootadministrator = new TreeItem<String>("Root node");
		
		treeRootadministrator.getChildren().addAll(Arrays.asList(
			new TreeItem<String>("manageUser"),
			new TreeItem<String>("manageStock")
					));
		
		treeRootadministrator.setExpanded(true);

		actor_treeview_administrator.setShowRoot(false);
		actor_treeview_administrator.setRoot(treeRootadministrator);
		
		//TreeView click, then open the GridPane for inputing parameters
		actor_treeview_administrator.getSelectionModel().selectedItemProperty().addListener(
						 (observable, oldValue, newValue) -> { 
						 								
						 							 //clear the previous return
													 operation_return_pane.setContent(new Label());
													 
						 							 clickedOp = newValue.getValue();
						 							 GridPane op = operationPanels.get(clickedOp);
						 							 VBox vb = opInvariantPanel.get(clickedOp);
						 							 
						 							 //op pannel
						 							 if (op != null) {
						 								 operation_paras.setContent(operationPanels.get(newValue.getValue()));
						 								 
						 								 ObservableList<Node> l = operationPanels.get(newValue.getValue()).getChildren();
						 								 choosenOperation = new LinkedList<TextField>();
						 								 for (Node n : l) {
						 								 	 if (n instanceof TextField) {
						 								 	 	choosenOperation.add((TextField)n);
						 								 	  }
						 								 }
						 								 
						 								 definition.setText(definitions_map.get(newValue.getValue()));
						 								 precondition.setText(preconditions_map.get(newValue.getValue()));
						 								 postcondition.setText(postconditions_map.get(newValue.getValue()));
						 								 
						 						     }
						 							 else {
						 								 Label l = new Label(newValue.getValue() + " is no contract information in requirement model.");
						 								 l.setPadding(new Insets(8, 8, 8, 8));
						 								 operation_paras.setContent(l);
						 							 }	
						 							 
						 							 //op invariants
						 							 if (vb != null) {
						 							 	ScrollPane scrollPane = new ScrollPane(vb);
						 							 	scrollPane.setFitToWidth(true);
						 							 	invariants_panes.setMaxHeight(200); 
						 							 	//all_invariant_pane.setContent(scrollPane);	
						 							 	
						 							 	invariants_panes.setContent(scrollPane);
						 							 } else {
						 							 	 Label l = new Label(newValue.getValue() + " is no related invariants");
						 							     l.setPadding(new Insets(8, 8, 8, 8));
						 							     invariants_panes.setContent(l);
						 							 }
						 							 
						 							 //reset pre- and post-conditions area color
						 							 precondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF ");
						 							 postcondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF");
						 							 //reset condition panel title
						 							 precondition_pane.setText("Precondition");
						 							 postcondition_pane.setText("Postcondition");
						 						} 
						 				);
		TreeItem<String> treeRootcustomer = new TreeItem<String>("Root node");
		
		treeRootcustomer.getChildren().addAll(Arrays.asList(
			new TreeItem<String>("viewProduct"),
			new TreeItem<String>("selectItem"),
			new TreeItem<String>("processSale")
					));
		
		treeRootcustomer.setExpanded(true);

		actor_treeview_customer.setShowRoot(false);
		actor_treeview_customer.setRoot(treeRootcustomer);
		
		//TreeView click, then open the GridPane for inputing parameters
		actor_treeview_customer.getSelectionModel().selectedItemProperty().addListener(
						 (observable, oldValue, newValue) -> { 
						 								
						 							 //clear the previous return
													 operation_return_pane.setContent(new Label());
													 
						 							 clickedOp = newValue.getValue();
						 							 GridPane op = operationPanels.get(clickedOp);
						 							 VBox vb = opInvariantPanel.get(clickedOp);
						 							 
						 							 //op pannel
						 							 if (op != null) {
						 								 operation_paras.setContent(operationPanels.get(newValue.getValue()));
						 								 
						 								 ObservableList<Node> l = operationPanels.get(newValue.getValue()).getChildren();
						 								 choosenOperation = new LinkedList<TextField>();
						 								 for (Node n : l) {
						 								 	 if (n instanceof TextField) {
						 								 	 	choosenOperation.add((TextField)n);
						 								 	  }
						 								 }
						 								 
						 								 definition.setText(definitions_map.get(newValue.getValue()));
						 								 precondition.setText(preconditions_map.get(newValue.getValue()));
						 								 postcondition.setText(postconditions_map.get(newValue.getValue()));
						 								 
						 						     }
						 							 else {
						 								 Label l = new Label(newValue.getValue() + " is no contract information in requirement model.");
						 								 l.setPadding(new Insets(8, 8, 8, 8));
						 								 operation_paras.setContent(l);
						 							 }	
						 							 
						 							 //op invariants
						 							 if (vb != null) {
						 							 	ScrollPane scrollPane = new ScrollPane(vb);
						 							 	scrollPane.setFitToWidth(true);
						 							 	invariants_panes.setMaxHeight(200); 
						 							 	//all_invariant_pane.setContent(scrollPane);	
						 							 	
						 							 	invariants_panes.setContent(scrollPane);
						 							 } else {
						 							 	 Label l = new Label(newValue.getValue() + " is no related invariants");
						 							     l.setPadding(new Insets(8, 8, 8, 8));
						 							     invariants_panes.setContent(l);
						 							 }
						 							 
						 							 //reset pre- and post-conditions area color
						 							 precondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF ");
						 							 postcondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF");
						 							 //reset condition panel title
						 							 precondition_pane.setText("Precondition");
						 							 postcondition_pane.setText("Postcondition");
						 						} 
						 				);
	}

	/**
	*    Execute Operation
	*/
	@FXML
	public void execute(ActionEvent event) {
		
		switch (clickedOp) {
		
		}
		
		System.out.println("execute buttion clicked");
		
		//checking relevant invariants
		opInvairantPanelUpdate();
	}

	/**
	*    Refresh All
	*/		
	@FXML
	public void refresh(ActionEvent event) {
		
		refreshAll();
		System.out.println("refresh all");
	}		
	
	/**
	*    Save All
	*/			
	@FXML
	public void save(ActionEvent event) {
		
		Stage stage = (Stage) mainPane.getScene().getWindow();
		
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Save State to File");
		fileChooser.setInitialFileName("*.state");
		fileChooser.getExtensionFilters().addAll(
		         new ExtensionFilter("RMCode State File", "*.state"));
		
		File file = fileChooser.showSaveDialog(stage);
		
		if (file != null) {
			System.out.println("save state to file " + file.getAbsolutePath());				
			EntityManager.save(file);
		}
	}
	
	/**
	*    Load All
	*/			
	@FXML
	public void load(ActionEvent event) {
		
		Stage stage = (Stage) mainPane.getScene().getWindow();
		
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Open State File");
		fileChooser.getExtensionFilters().addAll(
		         new ExtensionFilter("RMCode State File", "*.state"));
		
		File file = fileChooser.showOpenDialog(stage);
		
		if (file != null) {
			System.out.println("choose file" + file.getAbsolutePath());
			EntityManager.load(file); 
		}
		
		//refresh GUI after load data
		refreshAll();
	}
	
	
	//precondition unsat dialog
	public void preconditionUnSat() {
		
		Alert alert = new Alert(AlertType.WARNING, "");
        alert.initModality(Modality.APPLICATION_MODAL);
        alert.initOwner(mainPane.getScene().getWindow());
        alert.getDialogPane().setContentText("Precondtion is not satisfied");
        alert.getDialogPane().setHeaderText(null);
        alert.showAndWait();	
	}
	
	//postcondition unsat dialog
	public void postconditionUnSat() {
		
		Alert alert = new Alert(AlertType.WARNING, "");
        alert.initModality(Modality.APPLICATION_MODAL);
        alert.initOwner(mainPane.getScene().getWindow());
        alert.getDialogPane().setContentText("Postcondtion is not satisfied");
        alert.getDialogPane().setHeaderText(null);
        alert.showAndWait();	
	}

	public void thirdpartyServiceUnSat() {
		
		Alert alert = new Alert(AlertType.WARNING, "");
        alert.initModality(Modality.APPLICATION_MODAL);
        alert.initOwner(mainPane.getScene().getWindow());
        alert.getDialogPane().setContentText("third party service is exception");
        alert.getDialogPane().setHeaderText(null);
        alert.showAndWait();	
	}		
	
	




	//select object index
	int objectindex;
	
	@FXML
	TabPane mainPane;

	@FXML
	TextArea log;
	
	@FXML
	TreeView<String> actor_treeview_cashier;
	@FXML
	TreeView<String> actor_treeview_administrator;
	@FXML
	TreeView<String> actor_treeview_customer;
	


	@FXML
	TextArea definition;
	@FXML
	TextArea precondition;
	@FXML
	TextArea postcondition;
	@FXML
	TextArea invariants;
	
	@FXML
	TitledPane precondition_pane;
	@FXML
	TitledPane postcondition_pane;
	
	//chosen operation textfields
	List<TextField> choosenOperation;
	String clickedOp;
		
	@FXML
	TableView<ClassInfo> class_statisic;
	@FXML
	TableView<AssociationInfo> association_statisic;
	
	Map<String, ObservableList<AssociationInfo>> allassociationData;
	ObservableList<ClassInfo> classInfodata;
	
	SuperMarketSystem supermarketsystem_service;
	ThirdPartyServices thirdpartyservices_service;
	StartNewSaleService startnewsaleservice_service;
	ScanItemService scanitemservice_service;
	
	ClassInfo customer;
	ClassInfo sale;
	ClassInfo saleslineitem;
	ClassInfo productcataloge;
	ClassInfo store;
	ClassInfo payment;
		
	@FXML
	TitledPane object_statics;
	Map<String, TableView> allObjectTables;
	
	@FXML
	TitledPane operation_paras;
	
	@FXML
	TitledPane operation_return_pane;
	
	@FXML 
	TitledPane all_invariant_pane;
	
	@FXML
	TitledPane invariants_panes;
	
	Map<String, GridPane> operationPanels;
	Map<String, VBox> opInvariantPanel;
	
	//all textfiled or eumntity
	
	HashMap<String, String> definitions_map;
	HashMap<String, String> preconditions_map;
	HashMap<String, String> postconditions_map;
	HashMap<String, String> invariants_map;
	LinkedHashMap<String, String> service_invariants_map;
	LinkedHashMap<String, String> entity_invariants_map;
	LinkedHashMap<String, Label> service_invariants_label_map;
	LinkedHashMap<String, Label> entity_invariants_label_map;
	LinkedHashMap<String, Label> op_entity_invariants_label_map;
	LinkedHashMap<String, Label> op_service_invariants_label_map;
	

	
}
